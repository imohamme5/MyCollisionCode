using System;
using Sce.PlayStation.HighLevel.GameEngine2D;
using Sce.PlayStation.HighLevel.GameEngine2D.Base;
using Sce.PlayStation.Core;

namespace SpriteCollision
{
	public class CollisionScene :Scene
	{
		// Sprite declaration
		SpriteUV shape1;
		SpriteUV shape2;
		
		// Bounding Box declaration
		Rectangle box1;
		Rectangle box2;
		
		// SPEED CONSTANT
		const float MOVESPEED = 50;
		
		public CollisionScene ()
		{
			this.Camera.SetViewFromViewport();
			Scheduler.Instance.ScheduleUpdateForTarget(this, 0, false);
			// Load the sprites
			shape1 = new SpriteUV(new TextureInfo("/Application/Textures/Shape1.png"));
			shape2 = new SpriteUV(new TextureInfo("/Application/Textures/Shape2.png"));
			///////////////////////////////////////////////////////////////////////////
			
			// Set the position and size of the sprites
			shape1.Position = new Sce.PlayStation.Core.Vector2(10, 10);
			shape1.Quad.S = shape1.TextureInfo.TextureSizef;
			shape2.Position = new Sce.PlayStation.Core.Vector2(600, 190);
			shape2.Quad.S = shape2.TextureInfo.TextureSizef;
			//////////////////////////////////////////////////////////////////////////
			
			// Add the shapes to the Scene (see base class for CollisionScene - hence the use of this keyword)
			this.AddChild(shape1);
			this.AddChild(shape2);
		}
		
		
		public override void Update (float dt)
		{
			// Get any user input and move the boxes
			if(Input2.GamePad0.Left.Down)
			{
				shape1.Position += new Vector2((-MOVESPEED * dt), 0);
			}
			if(Input2.GamePad0.Right.Down)
			{
				shape1.Position += new Vector2((MOVESPEED * dt), 0);
			}
			if(Input2.GamePad0.Up.Down)
			{
				shape1.Position += new Vector2(0, (MOVESPEED * dt));
			}
			if(Input2.GamePad0.Down.Down)
			{
				shape1.Position += new Vector2(0, (-MOVESPEED * dt));
			}
			
			// Each update we re-create the rectangle around the sprite
			box1 = new Rectangle(shape1.Position.X, shape1.Position.Y, shape1.TextureInfo.Texture.Width, shape1.TextureInfo.Texture.Height);
			box2 = new Rectangle(shape2.Position.X, shape2.Position.Y, shape2.TextureInfo.Texture.Width, shape2.TextureInfo.Texture.Height);
			
			
			
			DoBoxesIntersect(box1, box2);
		}
		
		private void DoBoxesIntersect(Rectangle a, Rectangle b)
		{
			if (a.X < b.X + b.Width && 
			    a.X + a.Width > b.X && 
			    a.Y < b.Y + b.Height && 
			    a.Height + a.Y > b.Y) 
			{
    			Console.WriteLine("Collision Detected");
			}
			else
			{
				Console.WriteLine("No Collision");	
			}
			
		}
	}
}

